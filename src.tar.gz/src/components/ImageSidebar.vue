<template>
  <div class="image-sidebar">
    <img v-for="(img, index) in images" id="index" draggable="true" :key="index" :src="require(`@/assets/${img}`)" @dragstart="dragStart"/>
  </div>
</template>

<script>
export default {
  data() {
    return {
      images: ["logo.png", "1.png"] // 静态图片路径
    };
  },
  methods: {
    dragStart(event) {
      event.dataTransfer.setData("text/plain", event.target.id);
    }
  }
};
</script>