<template>
  <div>
    <canvas ref="canvas" width="600" height="400" @dragover.prevent @drop="handleDrop"></canvas>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ctx: null, // 用于存储canvas的上下文
      images: [], // 存储画布上的图片
    };
  },
  mounted() {
    this.initCanvas();
  },
  methods: {
    // 初始化canvas
    initCanvas() {
      const canvas = this.$refs.canvas;
      this.ctx = canvas.getContext('2d');
    },

    // 下载图片到本地
    downloadImage(dataUrl, filename) {
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    },

    // 获取图片
    async getImage(text) {
      try {
        const response = await fetch(`http://127.0.0.1:5000/get_image?text=${text}`);
        const data = await response.json();
        const image = new Image();
        image.onload = () => {
          this.ctx.clearRect(0, 0, this.$refs.canvas.width, this.$refs.canvas.height);
          this.ctx.drawImage(image, 0, 0);
        };
        image.src = `data:image/png;base64,${data.image}`;
        const imageUrl = this.$refs.canvas.toDataURL('image/jpeg'); // 将canvas内容转换为图片
        this.downloadImage(imageUrl, 'downloaded_image.jpg'); // 调用下载函数
      } catch (error) {
        console.error('获取图片失败:', error);
      }
    },

    handleDrop(event) {
      const imageId = event.dataTransfer.getData("text/plain");
      const imageUrl = document.getElementById(imageId).src;
      const x = event.offsetX;
      const y = event.offsetY;

      // 添加图片信息到数组
      this.images.push({
        url: imageUrl,
        x: x,
        y: y,
        width: 100, // 初始宽度，需要根据实际情况调整
        height: 100, // 初始高度，需要根据实际情况调整
        selected: false, // 标记图片是否被选中
      });

      this.drawImages(); // 绘制所有图片
    },

    drawImages() {
      const canvas = this.$refs.canvas;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height); // 清除之前的绘制

      this.images.forEach(image => {
        const img = new Image();
        img.onload = () => {
          ctx.drawImage(img, image.x, image.y, image.width, image.height);
        };
        img.src = image.url;
      });
    },

  },
};
</script>