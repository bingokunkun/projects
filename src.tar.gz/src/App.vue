<template>
  <div id="app">
    <ImageSidebar />
    <!-- 其他组件和内容 -->
  </div>
  <div id="app">
    <input v-model="userText" placeholder="请输入文本">
    <button @click="submitText">显示图片</button>
    <ImageCanvas ref="canvasComponent" />
  </div>
</template>

<script>
// 引入ImageSidebar组件
import ImageSidebar from './components/ImageSidebar.vue';
import ImageCanvas from './components/ImageCanvas.vue';

export default {
  name: 'App',
  components: {
    ImageSidebar, // 注册ImageSidebar组件
    ImageCanvas,
    // 其他组件
  },
  data() {
    return {
      userText: '', //用户输入的文本
    };
  },
  methods: {
    submitText() {
      this.$refs.canvasComponent.getImage(this.userText);
    },
  },
};
</script>

<style>
/* 你的样式 */
</style>